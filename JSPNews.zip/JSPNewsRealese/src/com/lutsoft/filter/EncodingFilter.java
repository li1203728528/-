
package com.lutsoft.filter;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class EncodingFilter implements Filter
{
    public void doFilter(ServletRequest request, ServletResponse response,FilterChain chain) throws IOException, ServletException 
    {
        try 
        {
            request.setCharacterEncoding("utf-8");
            chain.doFilter(request, response);
        } catch (Throwable t) 
        {   
            t.printStackTrace();
        }
    }
    public void destroy(){  }
    public void init(FilterConfig filterConfig) {        }
    
}

