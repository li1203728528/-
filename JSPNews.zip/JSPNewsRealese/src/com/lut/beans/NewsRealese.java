package com.lut.beans;
public class NewsRealese {
public String newsid;
public String CLASSID;
public String KINDID;
public String MYOTHER;
public String HEADTITLE;
public String CONTENT;
public String CONNECTREALTIVE;
public String AUTHOR;
public String EDITOR;
public String NEWSFROM;
public String TOP;
public String NEWSTIME;
public String HITS;
public String STATE;
public String TAG;

public String getNewsid() {
	return newsid;
}
public String getCLASSID() {
	return CLASSID;
}
public String getKINDID() {
	return KINDID;
}
public String getMYOTHER() {
	return MYOTHER;
}
public String getHEADTITLE() {
	return HEADTITLE;
}
public String getCONTENT() {
	return CONTENT;
}
public String getCONNECTREALTIVE() {
	return CONNECTREALTIVE;
}
public String getAUTHOR() {
	return AUTHOR;
}
public String getEDITOR() {
	return EDITOR;
}
public String getNEWSFROM() {
	return NEWSFROM;
}
public String getTOP() {
	return TOP;
}
public String getNEWSTIME() {
	return NEWSTIME;
}
public String getHITS() {
	return HITS;
}
public String getSTATE() {
	return STATE;
}
public String getTAG() {
	return TAG;
}
public void setNewsid(String newsid) {
	this.newsid = newsid;
}
public void setCLASSID(String cLASSID) {
	CLASSID = cLASSID;
}
public void setKINDID(String kINDID) {
	KINDID = kINDID;
}
public void setMYOTHER(String mYOTHER) {
	MYOTHER = mYOTHER;
}
public void setHEADTITLE(String hEADTITLE) {
	HEADTITLE = hEADTITLE;
}
public void setCONTENT(String cONTENT) {
	CONTENT = cONTENT;
}
public void setCONNECTREALTIVE(String cONNECTREALTIVE) {
	CONNECTREALTIVE = cONNECTREALTIVE;
}
public void setAUTHOR(String aUTHOR) {
	AUTHOR = aUTHOR;
}
public void setEDITOR(String eDITOR) {
	EDITOR = eDITOR;
}
public void setNEWSFROM(String nEWSFROM) {
	NEWSFROM = nEWSFROM;
}
public void setTOP(String tOP) {
	TOP = tOP;
}
public void setNEWSTIME(String nEWSTIME) {
	NEWSTIME = nEWSTIME;
}
public void setHITS(String hITS) {
	HITS = hITS;
}
public void setSTATE(String sTATE) {
	STATE = sTATE;
}
public void setTAG(String tAG) {
	TAG = tAG;
}


    
}
