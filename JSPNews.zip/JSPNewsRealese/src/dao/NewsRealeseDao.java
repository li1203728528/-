package dao;

import com.lut.beans.NewsRealese;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class NewsRealeseDao {

    public ArrayList queryAllNews() throws Exception {
        Connection conn = null;
        ArrayList newsRealese = new ArrayList();
        try {
            //��ȡ����  
        	Class.forName("com.mysql.cj.jdbc.Driver");
       	 	String url = "jdbc:mysql://localhost:3306/test?serverTimezone=UTC";
       	 	conn = DriverManager.getConnection(url, "root", "123456");
            //����SQL��� 
            String sql = "select * from newmessage";//��ȡ
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while (rs.next()) {   //ʵ����VO
                NewsRealese news = new NewsRealese();
                news.setNewsid(rs.getString("newsid"));
                news.setCLASSID(rs.getString("CLASSID"));
                news.setKINDID(rs.getString("KINDID"));
                news.setMYOTHER(rs.getString("MYOTHER"));
                news.setHEADTITLE(rs.getString("HEADTITLE"));
                news.setCONTENT(rs.getString("CONTENT"));
                news.setCONNECTREALTIVE(rs.getString("CONNECTREALTIVE"));
                news.setAUTHOR(rs.getString("AUTHOR"));
                news.setEDITOR(rs.getString("EDITOR"));
                news.setNEWSFROM(rs.getString("NEWSFROM"));
                news.setTOP(rs.getString("TOP"));
                news.setNEWSTIME(rs.getString("NEWSTIME"));
                news.setHITS(rs.getString("HITS"));
                news.setSTATE(rs.getString("STATE"));
                news.setTAG(rs.getString("TAG"));
                newsRealese.add(news);
            }
            rs.close();
            stat.close();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
            try {//�ر�����
                if (conn != null) {
                    conn.close();
                    conn = null;
                }
            } catch (Exception ex) {
            }
            return newsRealese;
        }
    }
    //��ѯһ����Ϣ
    public ArrayList queryOneNews(int newsid) throws Exception {
        Connection conn = null;
        ArrayList newsRealese = new ArrayList();
        int temp_id = newsid;
        try {
            //��ȡ����  
        	Class.forName("com.mysql.cj.jdbc.Driver");
          	 String url = "jdbc:mysql://localhost:3306/test?serverTimezone=UTC";
          	 conn = DriverManager.getConnection(url, "root", "123456");
            //����SQL��� 
            Statement stat = conn.createStatement();
            String sql = "select * from newmessage where newsid=?";//��ȡnewsid��ʹ�ã������ַ���������ᷢ������
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.valueOf(newsid));
            ResultSet rs = ps.executeQuery();// ֮ǰ�Ѿ�����sql�ַ���������executeUpdate���޲εġ�              
            while (rs.next()) {   //ʵ����VO
                NewsRealese news = new NewsRealese();
                news.setNewsid(rs.getString("newsid"));
                news.setCLASSID(rs.getString("CLASSID"));
                news.setKINDID(rs.getString("KINDID"));
                news.setMYOTHER(rs.getString("MYOTHER"));
                news.setHEADTITLE(rs.getString("HEADTITLE"));
                news.setCONTENT(rs.getString("CONTENT"));
                news.setCONNECTREALTIVE(rs.getString("CONNECTREALTIVE"));
                news.setAUTHOR(rs.getString("AUTHOR"));
                news.setEDITOR(rs.getString("EDITOR"));
                news.setNEWSFROM(rs.getString("NEWSFROM"));
                news.setTOP(rs.getString("TOP"));
                news.setNEWSTIME(rs.getString("NEWSTIME"));
                news.setHITS(rs.getString("HITS"));
                news.setSTATE(rs.getString("STATE"));
                news.setTAG(rs.getString("TAG"));
                newsRealese.add(news);
            }
            rs.close();
            stat.close();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
            try {//�ر�����
                if (conn != null) {
                    conn.close();
                    conn = null;
                }
            } catch (Exception ex) {
            }
            return newsRealese;
        }
    }
    //ɾ������
    @SuppressWarnings("finally")
    public String deleteOneNews(int newsid) throws Exception {
    	Connection conn = null;
    	ArrayList newsRealese = new ArrayList();
    	try {
    		//��ȡ���� 
    		Class.forName("com.mysql.cj.jdbc.Driver");
          	 String url = "jdbc:mysql://localhost:3306/test?serverTimezone=UTC";
          	 conn = DriverManager.getConnection(url, "root", "123456");
    		
    		//����SQL��� 
    		 Statement stat = conn.createStatement();
    		 String sql = "DELETE FROM newmessage WHERE newsid='"+newsid+"'";
    		 PreparedStatement ps = conn.prepareStatement(sql);
    		 ps.executeUpdate();
    		 stat.close();
    		 } catch (Exception e1) {
    		 e1.printStackTrace();
    		 } finally {
    			 try {//�ر�����
    				 if (conn != null) {
    				 conn.close();
    				 conn = null;
    				 }
    			 } catch (Exception ex) {
    			 }
    			 return newsRealese.toString();
    		 }
    	 }
    //��������
    public String insertOneNews(ArrayList addnews_list) throws Exception {
   	 Connection conn = null;
   	 try {
   		 //��ȡ����
   		Class.forName("com.mysql.cj.jdbc.Driver");
     	 String url = "jdbc:mysql://localhost:3306/test?serverTimezone=UTC";
     	 conn = DriverManager.getConnection(url, "root", "123456");
     	 System.out.println(addnews_list.get(0));
   		 int newsid=Integer.valueOf(addnews_list.get(0).toString());	
   		 String CLASSID=addnews_list.get(1).toString();
   		 String KINDID=addnews_list.get(2).toString();
   		 String MYOTHER=addnews_list.get(3).toString();	
   		 String HEADTITLE=addnews_list.get(4).toString();
   		 String CONTENT=addnews_list.get(5).toString();
   		 String CONNECTREALTIVE=addnews_list.get(6).toString();
   		 String AUTHOR=addnews_list.get(7).toString();
   		 String EDITOR=addnews_list.get(8).toString();
   		 String NEWSFROM=addnews_list.get(9).toString();
   		 String TOP=addnews_list.get(10).toString();
   		 String NEWSTIME=addnews_list.get(11).toString();
   		 String HITS=addnews_list.get(12).toString();
   		 String STATE=addnews_list.get(13).toString();
   		 String TAG=addnews_list.get(14).toString();
   		 SimpleDateFormat a=new SimpleDateFormat("yyyy-MM-dd");
   		 java.util.Date b=a.parse(NEWSTIME);
   		 String sql =  "insert into newmessage(newsid,CLASSID,KINDID,MYOTHER,HEADTITLE,CONTENT,CONNECTREALTIVE,AUTHOR,EDITOR,NEWSFROM,TOP,NEWSTIME,HITS,STATE,TAG) VALUES('"+newsid+"','"+CLASSID+"','"+KINDID+"','"+MYOTHER+"','"+HEADTITLE+"','"+CONTENT+"','"+CONNECTREALTIVE+"','"+AUTHOR+"','"+EDITOR+"','"+NEWSFROM+"','"+TOP+"','"+NEWSTIME+"','"+HITS+"','"+STATE+"','"+TAG+"')";
   		 Statement stmt=conn.createStatement();
   		 stmt.executeUpdate(sql);
   		 System.out.println("ok");
   	 } catch (Exception e1) {
   	 e1.printStackTrace();
   	 } finally {
   		 try {//�ر�����
   			 if (conn != null) {
   			 conn.close();
   			 conn = null;
   			 }
   		 } catch (Exception ex) {
   		 }
   	 } 
   	 return "ok";
    	}
    
    //��������
    public String updateOneNews(ArrayList addnews_list) throws Exception {
   	 Connection conn = null;
   	 try {
   		 //��ȡ����
   		Class.forName("com.mysql.cj.jdbc.Driver");
     	 String url = "jdbc:mysql://localhost:3306/test?serverTimezone=UTC";
     	 conn = DriverManager.getConnection(url, "root", "123456");
     	 System.out.println(addnews_list.get(0));
     	 int newsid=Integer.valueOf(addnews_list.get(0).toString());	
  		 String CLASSID=addnews_list.get(1).toString();
  		 String KINDID=addnews_list.get(2).toString();
  		 String MYOTHER=addnews_list.get(3).toString();	
  		 String HEADTITLE=addnews_list.get(4).toString();
  		 String CONTENT=addnews_list.get(5).toString();
  		 String CONNECTREALTIVE=addnews_list.get(6).toString();
  		 String AUTHOR=addnews_list.get(7).toString();
  		 String EDITOR=addnews_list.get(8).toString();
  		 String NEWSFROM=addnews_list.get(9).toString();
  		 String TOP=addnews_list.get(10).toString();
  		 String NEWSTIME=addnews_list.get(11).toString();
  		 String HITS=addnews_list.get(12).toString();
  		 String STATE=addnews_list.get(13).toString();
  		 String TAG=addnews_list.get(14).toString();
  		 SimpleDateFormat a=new SimpleDateFormat("yyyy-MM-dd");
  		 java.util.Date b=a.parse(NEWSTIME);
   		String sql =  "UPDATE newmessage set newsid='"+newsid+"',CLASSID='"+CLASSID+"',"
   				+ "KINDID='"+KINDID+"',MYOTHER='"+MYOTHER+"',HEADTITLE='"+HEADTITLE+"',"
   						+ "CONTENT='"+CONTENT+"',CONNECTREALTIVE='"+CONNECTREALTIVE+"',"
   								+ "AUTHOR='"+AUTHOR+"',EDITOR='"+EDITOR+"',NEWSFROM='"+NEWSFROM+"',"
   										+ "TOP='"+TOP+"',NEWSTIME='"+NEWSTIME+"',HITS='"+HITS+"',"
   												+ "STATE='"+STATE+"',TAG='"+TAG+"' where newsid="+newsid+""; 
   		Statement stmt=conn.createStatement();
   		stmt.executeUpdate(sql);
   	 } catch (Exception e1) {
   		 e1.printStackTrace();
   		 } finally {
   			 try {//�ر�����
   				 if (conn != null) {
   				 conn.close();
   				 conn = null;
   				 }
   			 } catch (Exception ex) {
   			 }
   		 } 
   	 return "ok";
    	}
    //�����µ��û�
    public String addAdmin(ArrayList addnews_list) throws Exception {
      	 Connection conn = null;
      	 try {
      		 //��ȡ����
      		Class.forName("com.mysql.cj.jdbc.Driver");
        	 String url = "jdbc:mysql://localhost:3306/test?serverTimezone=UTC";
        	 conn = DriverManager.getConnection(url, "root", "123456");
        	 System.out.println(addnews_list.get(0));
      		 int adminid=Integer.valueOf(addnews_list.get(0).toString());	
      		 String adminname=addnews_list.get(1).toString();
      		 String adminpass=addnews_list.get(2).toString();	
      		 String sql =  "insert into admin(adminid,adminname,adminpass) VALUES('"+adminid+"','"+adminname+"','"+adminpass+"')";
      		 Statement stmt=conn.createStatement();
      		 stmt.executeUpdate(sql);
      		 System.out.println("ok");
      	 } catch (Exception e1) {
      	 e1.printStackTrace();
      	 } finally {
      		 try {//�ر�����
      			 if (conn != null) {
      			 conn.close();
      			 conn = null;
      			 }
      		 } catch (Exception ex) {
      		 }
      	 } 
      	 return "ok";
       	}
   }
