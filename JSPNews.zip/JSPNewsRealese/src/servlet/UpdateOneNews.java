/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package servlet;

import dao.NewsRealeseDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name ="/UpdateOneNews",urlPatterns="/UpdateOneNews")
public class UpdateOneNews extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	response.setContentType("text/html;charset=utf-8");
    	request.setCharacterEncoding("utf-8");
        try (PrintWriter out = response.getWriter()) {
            ArrayList addnews_list = new ArrayList();
            NewsRealeseDao newsRealeseDao = new NewsRealeseDao();
            addnews_list.add(0, request.getParameter("newsid"));
            addnews_list.add(1, request.getParameter("CLASSID"));
            addnews_list.add(2, request.getParameter("KINDID"));
            addnews_list.add(3, request.getParameter("MYOTHER"));
            addnews_list.add(4, request.getParameter("HEADTITLE"));
            addnews_list.add(5, request.getParameter("CONTENT"));
            addnews_list.add(6, request.getParameter("CONNECTREALTIVE"));
            addnews_list.add(7, request.getParameter("AUTHOR"));
            addnews_list.add(8, request.getParameter("EDITOR"));
            addnews_list.add(9, request.getParameter("NEWSFROM"));
            addnews_list.add(10, request.getParameter("TOP"));
            addnews_list.add(11, request.getParameter("NEWSTIME"));
            addnews_list.add(12, request.getParameter("HITS"));
            addnews_list.add(13, request.getParameter("STATE"));
            addnews_list.add(14,request.getParameter("TAG"));
   try {
                 String newsRealese = newsRealeseDao.updateOneNews(addnews_list);
                if (newsRealese!= null) {
                    response.sendRedirect("adminManager.jsp");
                } else {
                    response.sendRedirect("a_addNews.jsp");
                }
            } catch (Exception ex) {
                Logger.getLogger(checkLogin.class.getName()).log(Level.SEVERE, null, ex);
			 }
		 }
	 }
@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
processRequest(request, response);
}
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
processRequest(request, response);
}
@Override
public String getServletInfo() {
return "Short description";
}

}
