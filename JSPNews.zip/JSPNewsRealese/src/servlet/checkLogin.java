package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name ="/checkLogin",urlPatterns="/checkLogin")
public class checkLogin extends HttpServlet {
 protected void processRequest(HttpServletRequest request, HttpServletResponse response)
 throws ServletException, IOException {
 request.setCharacterEncoding("utf-8");
 response.setContentType("text/html;charset=UTF-8");
 String user=request.getParameter("user");
 String pass=request.getParameter("pass");
 if(user==null || pass==null) {
	 System.out.println("�û��������벻��Ϊ��");
	 return;
 }
 Connection conn = null;
 try {
	Class.forName("com.mysql.cj.jdbc.Driver");
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	String url="jdbc:mysql://localhost:3306/test?serverTimezone=UTC";
	try {

		conn=DriverManager.getConnection(url,"root", "123456");
		String sql = "select * from admin where adminname='"+user+"' and adminpass='"+pass+"'";//��ȡ
		System.out.println(sql);
		Statement stat = conn.createStatement();
		ResultSet rs = stat.executeQuery(sql);
		if(rs.next()) {
			response.sendRedirect("adminManager.jsp");
		}else {
			System.out.println("�û������������");
			response.sendRedirect("adminLogin.jsp");		
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	 //����SQL��� 
	 
 }
 @Override
 protected void doGet(HttpServletRequest request, HttpServletResponse response)
 throws ServletException, IOException {
 processRequest(request, response);
 }
 @Override
 protected void doPost(HttpServletRequest request, HttpServletResponse response)
 throws ServletException, IOException {
 processRequest(request, response);
 }

 @Override
 public String getServletInfo() {
 return "Short description"+"public String getServletInfo() ";
 }// </editor-fold>
}
